/**
 * Email Ingestion Service
 * Fetches emails from Gmail and processes them into the system
 */

import {
  fetchUnreadEmails,
  fetchRecentEmails,
  extractEmailAddress,
  extractName,
  getUserEmail,
  type EmailMessage,
} from '@/lib/google/gmail'
import { filterEmail, classifyEmail, enrichMessage, enrichedTextToString } from '@/lib/ai/gemini'
import { findOrCreateCP, isSameGmailAddress } from '@/lib/db/counterparties'
import { createMessage, messageExists, updateMessage } from '@/lib/db/messages'
import { getUserById, upsertUser, getUserSettings } from '@/lib/db/users'
import { generateMessageEmbedding, cleanMessageText, cleanMessageTextForEnrichment } from '@/lib/embeddings/generate'
import { saveMessageEmbedding } from '@/lib/db/embeddings'
import { v4 as uuidv4 } from 'uuid'
import { isMilaCommand, classifyCommand } from '@/lib/commands'
import { executeCommand } from '@/lib/commands'
import { writeAuditLog } from '@/lib/db/gdpr'
import { createTimelineEntry } from '@/lib/db/timeline'

/**
 * Senders that are always skipped — no message or CP is created for these.
 * Hard-coded list checked BEFORE the AI classifier runs so we don't waste
 * tokens on obvious automated / no-reply / transactional mail.
 *
 * Rules:
 *  - Exact email matches go in BLOCKED_SENDERS.
 *  - Prefix patterns go in BLOCKED_SENDER_PREFIXES (matched against the local
 *    part before the @).
 *  - Domain patterns go in BLOCKED_SENDER_DOMAINS (matched against the domain
 *    part after the @).
 */
const BLOCKED_SENDERS = [
  // Google
  'no-reply@accounts.google.com',
  'noreply@google.com',
  'calendar-notification@google.com',
  'notifications@google.com',
  'drive-shares-dm-noreply@google.com',
  // X / Twitter
  'info@x.com',
  'verify@x.com',
  'noreply@x.com',
  // Supabase
  'noreply@supabase.io',
  'noreply@supabase.com',
  'noreply@mail.supabase.com',
  'noreply@notifications.supabase.com',
  // GitHub
  'noreply@github.com',
  'notifications@github.com',
  // Vercel
  'noreply@vercel.com',
  'ship@vercel.com',
  // Stripe
  'noreply@stripe.com',
  'receipts@stripe.com',
  // LinkedIn
  'messages-noreply@linkedin.com',
  'invitations@linkedin.com',
  // Common transactional
  'mailer-daemon@googlemail.com',
  'postmaster@googlemail.com',
]

/** Local-part prefixes that indicate automated mail (before the @). */
const BLOCKED_SENDER_PREFIXES = [
  'noreply',
  'no-reply',
  'no_reply',
  'donotreply',
  'do-not-reply',
  'do_not_reply',
  'mailer-daemon',
  'postmaster',
  'notifications',
  'notification',
  'automated',
  'auto-confirm',
  'bounce',
]

/** Domains that only send automated / transactional mail. */
const BLOCKED_SENDER_DOMAINS = [
  'amazonses.com',
  'sendgrid.net',
  'mailgun.org',
  'mandrillapp.com',
  'postmarkapp.com',
  'email.shopify.com',
  'notify.bugsnag.com',
  'mailer.hetzner.com',
]

/** Returns true if the sender should be blocked before AI classification. */
export function isBlockedSender(email: string): boolean {
  const lower = email.toLowerCase()
  if (BLOCKED_SENDERS.includes(lower)) return true

  const atIndex = lower.indexOf('@')
  if (atIndex === -1) return false

  const local = lower.slice(0, atIndex)
  const domain = lower.slice(atIndex + 1)

  if (BLOCKED_SENDER_PREFIXES.some(p => local === p || local.startsWith(p + '+'))) return true
  if (BLOCKED_SENDER_DOMAINS.includes(domain)) return true

  return false
}

export interface IngestedMessage {
  id: string
  email: EmailMessage
  cpId: string
  isActionable: boolean
  category: string
}

/**
 * Helper: Ensure user email is known and normalized
 */
async function getNormalizedUserEmail(userId: string): Promise<string> {
  let user = await getUserById(userId)
  if (!user) throw new Error(`User not found: ${userId}`)

  // If email is missing in DB, fetch from Gmail and update DB
  if (!user.email) {
    try {
      const emailFromGmail = await getUserEmail(userId)
      if (emailFromGmail) {
        user = await upsertUser({
          ...user,
          email: emailFromGmail,
        })
      }
    } catch (error) {
      console.error(`[Ingest] Failed to fetch user email from Gmail:`, error)
    }
  }

  if (!user.email) {
    throw new Error(`User ${userId} has no email address configured`)
  }

  return user.email.toLowerCase()
}

/**
 * Ingest emails for a user
 */
export async function ingestEmailsForUser(
  userId: string,
  maxEmails: number = 50
): Promise<IngestedMessage[]> {
  const userEmail = await getNormalizedUserEmail(userId)
  const settings = await getUserSettings(userId)

  // Fetch unread emails
  const emails = await fetchUnreadEmails(userId, maxEmails)
  const ingestedMessages: IngestedMessage[] = []

  // Process emails in parallel batches — the AI classifyEmail() call is the
  // bottleneck (~200-500ms each). Batching 5 at a time gives ~5x speedup
  // while staying within Gemini rate limits.
  const INGESTION_CONCURRENCY = 5

  for (let i = 0; i < emails.length; i += INGESTION_CONCURRENCY) {
    const chunk = emails.slice(i, i + INGESTION_CONCURRENCY)
    const results = await Promise.allSettled(
      chunk.map(email => processOneInboundEmail(email, userId, userEmail, settings ?? undefined))
    )

    for (const result of results) {
      if (result.status === 'fulfilled' && result.value) {
        ingestedMessages.push(result.value)
      } else if (result.status === 'rejected') {
        console.error('[Ingest] Parallel email processing failed:', result.reason)
      }
    }
  }

  return ingestedMessages
}

/**
 * Process a single inbound email: dedup check → block check → classify → store.
 * Extracted to enable parallel processing of independent emails.
 */
async function processOneInboundEmail(
  email: EmailMessage,
  userId: string,
  userEmail: string,
  settings?: import('@/lib/supabase/types').UserSettings
): Promise<IngestedMessage | null> {
  // Check if already processed
  if (await messageExists(userId, email.id)) {
    return null
  }

  // Extract sender info
  const senderEmail = extractEmailAddress(email.from)
  const senderName = extractName(email.from)

  // Skip if sender is the user (outbound) — Gmail dot-insensitive
  // But first check for Mila command emails (self-email instructions)
  if (isSameGmailAddress(senderEmail, userEmail)) {
    if (isMilaCommand(email.subject)) {
      try {
        const parsed = await classifyCommand(email.subject, email.body)
        const result = await executeCommand(parsed, userId, settings)

        // Store as message to prevent re-processing (dedup via messageExists)
        await createMessage({
          user_id: userId,
          universal_message_id: email.id,
          external_id: email.id,
          external_thread_id: email.threadId,
          direction: 'internal',
          raw_text: email.body,
          tag_primary: 'mila_command',
          tag_secondary: parsed.type,
          message_type: null,
          timestamp: email.date.toISOString(),
        })

        await writeAuditLog({
          user_id: userId,
          action: `command:${parsed.type}`,
          details: { success: result.success, summary: result.summary },
        })

        console.log(`[Ingest] COMMAND ${parsed.type}: ${result.summary}`)
      } catch (error) {
        console.error(`[Ingest] Command parse/exec failed for ${email.id}:`, error)
        await writeAuditLog({
          user_id: userId,
          action: 'command:error',
          details: { emailId: email.id, error: error instanceof Error ? error.message : String(error) },
        })
      }
    }
    return null
  }

  // Hard-block known automated / no-reply senders before classification
  if (isBlockedSender(senderEmail)) {
    console.log(`[Ingest] SKIP blocked sender: ${senderEmail}`)
    return null
  }

  // AI filter: catch newsletters, automated notifications, marketing
  try {
    const filter = await filterEmail(email.subject, email.body, email.from)
    if (!filter.relevant) {
      console.log(`[Ingest] SKIP filter (not relevant): ${senderEmail} — "${email.subject}"`)
      // Store minimal record so we don't re-process next run
      await createMessage({
        id: uuidv4(),
        user_id: userId,
        cp_id: null,
        external_id: email.id,
        external_thread_id: email.threadId,
        universal_message_id: email.id,
        direction: 'inbound',
        raw_text: '',
        cleaned_text: null,
        tag_primary: 'filter_skip',
        tag_secondary: null,
        timestamp: email.date.toISOString(),
        occurred_at: email.date.toISOString(),
      })
      return null
    }
  } catch (error) {
    // Fail-open: if filter AI is unavailable, let the email through
    console.error(`[Ingest] Filter failed for ${email.id}, allowing (fail-open):`, error)
  }

  // Classify the email
  const classification = await classifyEmail(
    email.subject,
    email.body,
    email.from
  )

  // Store non-actionable emails as a minimal record so we never re-classify them.
  // No CP is created — we just need messageExists() to return true next run.
  if (!classification.isActionable) {
    const skippedId = uuidv4()
    await createMessage({
      id: skippedId,
      user_id: userId,
      cp_id: null,
      external_id: email.id,
      external_thread_id: email.threadId,
      universal_message_id: email.id,
      direction: 'inbound',
      raw_text: '',
      cleaned_text: null,
      tag_primary: 'non_actionable',
      tag_secondary: classification.category || null,
      timestamp: email.date.toISOString(),
      occurred_at: email.date.toISOString(),
    })
    return null
  }

  // Find or create the counterparty (null = user's own email, skip)
  const cp = await findOrCreateCP(userId, senderEmail, senderName || undefined)
  if (!cp) return null

  // Create the message record
  const messageId = uuidv4()
  await createMessage({
    id: messageId,
    user_id: userId,
    cp_id: cp.id,
    external_id: email.id,
    external_thread_id: email.threadId,
    universal_message_id: email.id,
    direction: 'inbound',
    raw_text: email.body,
    cleaned_text: cleanMessageText(email.body, 'email').slice(0, 5000),
    tag_primary: classification.category,
    tag_secondary: null,
    timestamp: email.date.toISOString(),
    occurred_at: email.date.toISOString(),
  })

  // Enrich message: extract key info, save enriched text
  // Use enrichment-safe cleaning (keeps signatures — they contain addresses and contact info)
  let enrichedText: string | null = null
  try {
    const textForEnrichment = cleanMessageTextForEnrichment(email.body, 'email')
    enrichedText = await enrichMessage(textForEnrichment, 'email', 'inbound', undefined, settings ?? undefined)
    await updateMessage(messageId, { enriched_text: enrichedText })
  } catch (error) {
    console.error(`[Enrichment] FAILED for inbound message ${messageId}:`, error)
  }

  // Embed the enriched text (not the raw body) — skip cleaning since enriched text is AI-generated
  if (enrichedText) {
    try {
      const embedding = await generateMessageEmbedding(enrichedText, 'email', true)
      await saveMessageEmbedding(messageId, embedding)
    } catch (error) {
      console.error(`[Embeddings] FAILED for inbound message ${messageId}:`, error)
    }
  }

  // Write to deal timeline — prefer enriched text (has structured scheduling data),
  // fall back to cleaned text if enrichment failed
  await createTimelineEntry({
    user_id: userId,
    cp_id: cp.id,
    event_type: 'email',
    direction: 'in',
    occurred_at: email.date.toISOString(),
    content: (enrichedText ? enrichedTextToString(enrichedText) : cleanMessageText(email.body, 'email')).slice(0, 5000),
    message_id: messageId,
  })

  return {
    id: messageId,
    email,
    cpId: cp.id,
    isActionable: classification.isActionable,
    category: classification.category,
  }
}

/**
 * Ingest outbound emails (for tracking user-initiated conversations)
 * Detects when user sends emails mentioning meetings/scheduling
 * so Mila can proactively check calendar and prepare slots.
 */
export async function ingestOutboundEmails(
  userId: string
): Promise<number> {
  const userEmail = await getNormalizedUserEmail(userId)
  const settings = await getUserSettings(userId)
  let ingested = 0

  try {
    // Fetch sent emails — no time filter, dedup via messageExists()
    const sentEmails = await fetchRecentEmails(userId, {
      maxResults: 50,
      labelIds: ['SENT'],
    })
    console.log(`[Ingest:DEBUG] SENT fetch returned ${sentEmails.length} emails`)

    // Process outbound emails in parallel batches
    const OUTBOUND_CONCURRENCY = 5

    for (let i = 0; i < sentEmails.length; i += OUTBOUND_CONCURRENCY) {
      const chunk = sentEmails.slice(i, i + OUTBOUND_CONCURRENCY)
      const results = await Promise.allSettled(
        chunk.map(email => processOneOutboundEmail(email, userId, userEmail, settings ?? undefined))
      )

      for (const result of results) {
        if (result.status === 'fulfilled' && result.value) {
          ingested++
        } else if (result.status === 'rejected') {
          console.error('[Ingest] Parallel outbound processing failed:', result.reason)
        }
      }
    }
  } catch (error) {
    console.error(`[Ingest] Failed to fetch sent emails for user ${userId}:`, error)
  }

  return ingested
}

/**
 * Process a single outbound email: dedup check → store → embed.
 * Extracted to enable parallel processing.
 */
async function processOneOutboundEmail(
  email: EmailMessage,
  userId: string,
  userEmail: string,
  settings?: import('@/lib/supabase/types').UserSettings
): Promise<boolean> {
  // Skip if already processed
  if (await messageExists(userId, email.id)) {
    console.log(`[Ingest:DEBUG] OUT skip: already exists — ${email.id}`)
    return false
  }

  // Sender is the user — extract recipients
  const senderEmail = extractEmailAddress(email.from)
  if (!isSameGmailAddress(senderEmail, userEmail)) {
    console.log(`[Ingest:DEBUG] OUT skip: sender "${senderEmail}" ≠ user "${userEmail}" — ${email.id}`)
    return false // Not from user, skip
  }

  // Get the first recipient as CP
  if (!email.to || email.to.length === 0) {
    console.log(`[Ingest:DEBUG] OUT skip: no recipients — ${email.id}`)
    return false
  }
  const recipientEmail = extractEmailAddress(email.to[0])
  const recipientName = extractName(email.to[0])

  // Skip if recipient is the user themselves
  if (isSameGmailAddress(recipientEmail, userEmail)) {
    console.log(`[Ingest:DEBUG] OUT skip: recipient is self "${recipientEmail}" — ${email.id}`)
    return false
  }

  // Skip blocked senders (in case user replies to automated)
  if (isBlockedSender(recipientEmail)) {
    console.log(`[Ingest] SKIP outbound to blocked recipient: ${recipientEmail}`)
    return false
  }

  // Find or create CP for the recipient (null = user's own email, skip)
  const cp = await findOrCreateCP(userId, recipientEmail, recipientName || undefined)
  if (!cp) return false

  // Create the message record as outbound
  const messageId = uuidv4()
  await createMessage({
    id: messageId,
    user_id: userId,
    cp_id: cp.id,
    external_id: email.id,
    external_thread_id: email.threadId,
    universal_message_id: email.id,
    direction: 'outbound',
    raw_text: email.body,
    cleaned_text: cleanMessageText(email.body, 'email').slice(0, 5000),
    tag_primary: 'outbound',
    tag_secondary: null,
    timestamp: email.date.toISOString(),
    occurred_at: email.date.toISOString(),
  })

  // Enrich message: extract key info, save enriched text
  // Use enrichment-safe cleaning (keeps signatures — they contain addresses and contact info)
  let enrichedText: string | null = null
  try {
    const textForEnrichment = cleanMessageTextForEnrichment(email.body, 'email')
    enrichedText = await enrichMessage(textForEnrichment, 'email', 'outbound', undefined, settings ?? undefined)
    await updateMessage(messageId, { enriched_text: enrichedText })
  } catch (error) {
    console.error(`[Enrichment] FAILED for outbound message ${messageId}:`, error)
  }

  // Embed the enriched text (not the raw body) — skip cleaning since enriched text is AI-generated
  if (enrichedText) {
    try {
      const embedding = await generateMessageEmbedding(enrichedText, 'email', true)
      await saveMessageEmbedding(messageId, embedding)
    } catch (error) {
      console.error(`[Embeddings] FAILED for outbound message ${messageId}:`, error)
    }
  }

  // Write to deal timeline — prefer enriched text (has structured scheduling data),
  // fall back to cleaned text if enrichment failed
  await createTimelineEntry({
    user_id: userId,
    cp_id: cp.id,
    event_type: 'email',
    direction: 'out',
    occurred_at: email.date.toISOString(),
    content: (enrichedText ? enrichedTextToString(enrichedText) : cleanMessageText(email.body, 'email')).slice(0, 5000),
    message_id: messageId,
  })

  return true
}
